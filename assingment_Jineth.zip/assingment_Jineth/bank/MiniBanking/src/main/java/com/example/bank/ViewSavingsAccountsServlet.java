package com.example.bank;

import com.example.bank.database.CustomerRepository;
import com.example.bank.model.Customer;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

public class ViewSavingsAccountsServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        List<Customer> accounts = CustomerRepository.getSavingsAccounts(); // ✅ Correct method
        req.setAttribute("savingsAccounts", accounts);
        req.getRequestDispatcher("/WEB-INF/view-savings-accounts.jsp").forward(req, res);
    }
}
