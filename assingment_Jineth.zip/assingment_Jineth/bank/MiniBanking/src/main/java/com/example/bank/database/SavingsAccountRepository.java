package com.example.bank.database;

import com.example.bank.model.SavingsAccount;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SavingsAccountRepository {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/online_banking";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "1234";

    public static boolean openNewSavingsAccount(String customerId, String openingDate, double initialDeposit) {
        String sql = "INSERT INTO SAVINGS_ACCOUNT (CUSTOMER_ID, OPENING_DATE, BALANCE) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, customerId);
            stmt.setDate(2, Date.valueOf(openingDate)); // expects yyyy-MM-dd
            stmt.setDouble(3, initialDeposit);

            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static List<SavingsAccount> getAllSavingsAccounts() {
        List<SavingsAccount> list = new ArrayList<>();
        String sql = "SELECT sa.ACCOUNT_NUMBER, sa.OPENING_DATE, sa.BALANCE, c.F_NAME, c.L_NAME, c.ID AS CUSTOMER_ID " +
                "FROM SAVINGS_ACCOUNT sa JOIN ACCOUNT c ON sa.CUSTOMER_ID = c.ID";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                SavingsAccount sa = new SavingsAccount();
                sa.setAccountNumber(rs.getInt("ACCOUNT_NUMBER"));
                sa.setOpeningDate(rs.getDate("OPENING_DATE").toString());
                sa.setBalance(rs.getDouble("BALANCE"));
                sa.setCustomerId(rs.getString("CUSTOMER_ID"));
                sa.setCustomerName(rs.getString("F_NAME") + " " + rs.getString("L_NAME"));

                list.add(sa);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
}
