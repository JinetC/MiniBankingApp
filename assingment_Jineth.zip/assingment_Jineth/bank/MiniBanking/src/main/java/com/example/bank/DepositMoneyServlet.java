package com.example.bank;

import com.example.bank.database.CustomerRepository;
import com.example.bank.model.Customer;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

public class DepositMoneyServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        List<Customer> customers = CustomerRepository.getAllCustomers();
        req.setAttribute("customers", customers);
        req.getRequestDispatcher("/WEB-INF/deposit-money.jsp").forward(req, res);
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        String id = req.getParameter("id");
        double amount = Double.parseDouble(req.getParameter("amount"));
        String date = req.getParameter("date");

        boolean success = CustomerRepository.depositAmount(id, amount, date);
        if (success) {
            req.setAttribute("message", "Deposit successful.");
        } else {
            req.setAttribute("message", "Deposit failed.");
        }
        doGet(req, res);  // reload form with message
    }
}
