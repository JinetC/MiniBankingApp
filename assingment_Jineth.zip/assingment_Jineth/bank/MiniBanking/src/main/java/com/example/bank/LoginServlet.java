package com.example.bank;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import com.example.bank.database.UserRepository;
import java.util.concurrent.ConcurrentHashMap;

public class LoginServlet extends HttpServlet {

    private static ConcurrentHashMap<String, String> users = new ConcurrentHashMap<>();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/login.jsp");
        dispatcher.forward(req, res);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String action = req.getParameter("action");

        // ✅ Hash the password before using it
        String hashedPassword = UserRepository.hashPassword(password);

        if ("signup".equals(action)) {
            if (UserRepository.userExists(username)) {
                req.setAttribute("message", "Username already exists.");
            } else {
                boolean success = UserRepository.registerUser(username, hashedPassword);
                req.setAttribute("message", success ? "Registration successful!" : "Registration failed.");
            }
            req.getRequestDispatcher("/WEB-INF/login.jsp").forward(req, res);

        } else if ("login".equals(action)) {
            if (UserRepository.validateUser(username, hashedPassword)) {
                req.getSession().setAttribute("username", username);
                res.sendRedirect("welcome");
            } else {
                req.setAttribute("message", "Invalid username or password.");
                req.getRequestDispatcher("/WEB-INF/login.jsp").forward(req, res);
            }
        }
    }
}
