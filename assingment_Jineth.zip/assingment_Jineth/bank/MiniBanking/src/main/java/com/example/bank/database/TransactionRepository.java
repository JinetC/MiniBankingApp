package com.example.bank.database;

import com.example.bank.model.Transaction;

import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TransactionRepository {

    private static Connection getConnection() throws SQLException {
        // Use your existing connection code
        // For example:
        return DatabaseConnection.getConnection();
    }

    public static boolean addTransaction(Transaction transaction) {
        String sql = "INSERT INTO TRANSACTIONS (CUSTOMER_ID, TRANSACTION_DATE, TYPE, AMOUNT, BALANCE_AFTER) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, transaction.getCustomerId());
            ps.setDate(2, new java.sql.Date(transaction.getDate().getTime()));
            ps.setString(3, transaction.getType());
            ps.setDouble(4, transaction.getAmount());
            ps.setDouble(5, transaction.getBalanceAfter());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static List<Transaction> getTransactionsByCustomerIdAndDateRange(String customerId, String fromDateStr, String toDateStr) {
        List<Transaction> list = new ArrayList<>();
        String sql = "SELECT * FROM TRANSACTIONS WHERE CUSTOMER_ID = ? AND TRANSACTION_DATE BETWEEN ? AND ? ORDER BY TRANSACTION_DATE DESC";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, customerId);
            ps.setDate(2, java.sql.Date.valueOf(fromDateStr));
            ps.setDate(3, java.sql.Date.valueOf(toDateStr));

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    int id = rs.getInt("TRANSACTION_ID");
                    Date date = rs.getDate("TRANSACTION_DATE");
                    String type = rs.getString("TYPE");
                    double amount = rs.getDouble("AMOUNT");
                    double balanceAfter = rs.getDouble("BALANCE_AFTER");

                    Transaction t = new Transaction(id, customerId, date, type, amount, balanceAfter);
                    list.add(t);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }
}
