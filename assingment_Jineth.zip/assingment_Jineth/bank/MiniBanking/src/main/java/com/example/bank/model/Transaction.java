package com.example.bank.model;

import java.util.Date;

/**
 * Represents a banking transaction (Deposit or Withdrawal).
 */
public class Transaction {
    private int transactionId;
    private String customerId;
    private Date date;
    private String type; // "Deposit" or "Withdraw"
    private double amount;
    private double balanceAfter;

    // No-arg constructor (required for some frameworks)
    public Transaction() {}

    // Full constructor
    public Transaction(int transactionId, String customerId, Date date, String type, double amount, double balanceAfter) {
        this.transactionId = transactionId;
        this.customerId = customerId;
        this.date = date;
        this.type = type;
        this.amount = amount;
        this.balanceAfter = balanceAfter;
    }

    // Constructor without ID (for insert cases before ID is generated)
    public Transaction(String customerId, Date date, String type, double amount, double balanceAfter) {
        this.customerId = customerId;
        this.date = date;
        this.type = type;
        this.amount = amount;
        this.balanceAfter = balanceAfter;
    }

    // Getters and setters
    public int getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(int transactionId) {
        this.transactionId = transactionId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public double getBalanceAfter() {
        return balanceAfter;
    }

    public void setBalanceAfter(double balanceAfter) {
        this.balanceAfter = balanceAfter;
    }
}
