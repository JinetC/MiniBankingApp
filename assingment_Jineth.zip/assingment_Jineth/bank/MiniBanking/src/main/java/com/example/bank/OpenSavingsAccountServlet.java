package com.example.bank;

import com.example.bank.database.CustomerRepository;
import com.example.bank.model.Customer;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

public class OpenSavingsAccountServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        List<Customer> customers = CustomerRepository.getAllCustomers();
        req.setAttribute("customers", customers);
        req.getRequestDispatcher("/WEB-INF/open-savings-account.jsp").forward(req, res);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        String id = req.getParameter("id");
        String date = req.getParameter("date");
        double deposit = Double.parseDouble(req.getParameter("deposit"));

        boolean success = CustomerRepository.updateBalanceAndDate(id, deposit, date);

        List<Customer> customers = CustomerRepository.getAllCustomers();
        req.setAttribute("customers", customers);

        if (success) {
            req.setAttribute("message", "Savings account opened successfully!");
        } else {
            req.setAttribute("message", "Failed to open account. Try again.");
        }

        req.getRequestDispatcher("/WEB-INF/open-savings-account.jsp").forward(req, res);
    }
}
