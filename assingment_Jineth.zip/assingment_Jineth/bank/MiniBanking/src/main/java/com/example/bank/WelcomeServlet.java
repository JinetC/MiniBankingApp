package com.example.bank;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class WelcomeServlet extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        HttpSession session = req.getSession(false); // don't create if not exists

        if (session != null && session.getAttribute("username") != null) {
            // User is logged in, forward to welcome.jsp
            RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/welcome.jsp");
            dispatcher.forward(req, res);
        } else {
            // No user in session, redirect to login page
            res.sendRedirect("login");
        }
    }
}
