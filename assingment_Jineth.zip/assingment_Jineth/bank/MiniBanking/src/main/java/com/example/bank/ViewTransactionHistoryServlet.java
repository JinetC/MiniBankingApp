package com.example.bank;

import com.example.bank.database.TransactionRepository;
import com.example.bank.model.Transaction;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

public class ViewTransactionHistoryServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        String id = req.getParameter("id");
        if (id == null || id.trim().isEmpty()) {
            req.setAttribute("error", "Customer ID is required.");
            req.getRequestDispatcher("/WEB-INF/view-transaction-history.jsp").forward(req, res);
            return;
        }
        req.setAttribute("customerId", id);
        req.getRequestDispatcher("/WEB-INF/view-transaction-history.jsp").forward(req, res);
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        String id = req.getParameter("id");
        String fromDate = req.getParameter("fromDate");
        String toDate = req.getParameter("toDate");

        List<Transaction> transactions = TransactionRepository.getTransactionsByCustomerIdAndDateRange(id, fromDate, toDate);
        req.setAttribute("transactions", transactions);
        req.setAttribute("customerId", id);
        req.setAttribute("fromDate", fromDate);
        req.setAttribute("toDate", toDate);

        req.getRequestDispatcher("/WEB-INF/view-transaction-history.jsp").forward(req, res);
    }
}
