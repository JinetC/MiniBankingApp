package com.example.bank;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import com.example.bank.database.CustomerRepository;

public class AddCustomerServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String fname = req.getParameter("fname");
        String lname = req.getParameter("lname");
        String address = req.getParameter("address");
        String city = req.getParameter("city");
        String branch = req.getParameter("branch");
        String zip = req.getParameter("zip");
        String dob = req.getParameter("dob");
        String nic = req.getParameter("nic");
        String phone = req.getParameter("phone");
        String email = req.getParameter("email");
        String accountType = req.getParameter("accountType");
        String regDate = req.getParameter("regDate");

        boolean success = CustomerRepository.insertCustomer(
                fname, lname, address, city, branch, zip, dob, nic, phone, email, accountType, regDate
        );

        req.setAttribute("message", success ? "Customer added successfully!" : "Error adding customer.");
        req.getRequestDispatcher("/WEB-INF/add-customer.jsp").forward(req, res);
    }

    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        req.getRequestDispatcher("/WEB-INF/add-customer.jsp").forward(req, res);
    }
}
