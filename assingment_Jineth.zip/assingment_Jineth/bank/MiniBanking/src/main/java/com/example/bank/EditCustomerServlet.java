package com.example.bank;

import com.example.bank.database.CustomerRepository;
import com.example.bank.model.Customer;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class EditCustomerServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        String id = req.getParameter("id");
        Customer customer = CustomerRepository.getCustomerById(id);

        if (customer == null) {
            req.setAttribute("errorMessage", "Customer with ID " + id + " not found.");
        } else {
            req.setAttribute("customer", customer);
        }

        req.getRequestDispatcher("/WEB-INF/edit-customer.jsp").forward(req, res);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        String id = req.getParameter("id");

        Customer customer = new Customer();
        customer.setFname(req.getParameter("fname"));
        customer.setLname(req.getParameter("lname"));
        customer.setAddress(req.getParameter("address"));
        customer.setCity(req.getParameter("city"));
        customer.setBranch(req.getParameter("branch"));
        customer.setZip(req.getParameter("zip"));
        customer.setDob(req.getParameter("dob"));
        customer.setPhone(req.getParameter("phone"));
        customer.setEmail(req.getParameter("email"));
        customer.setAccountType(req.getParameter("accountType"));
        customer.setRegDate(req.getParameter("regDate"));
        customer.setId(id); // important to keep ID for update

        boolean updated = CustomerRepository.updateCustomerById(id, customer);
        if (updated) {
            res.sendRedirect("view-customers");
        } else {
            req.setAttribute("error", "Update failed.");
            req.setAttribute("customer", customer);
            req.getRequestDispatcher("/WEB-INF/edit-customer.jsp").forward(req, res);
        }
    }
}
