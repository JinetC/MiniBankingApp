package com.example.bank;

import com.example.bank.database.CustomerRepository;
import com.example.bank.model.Customer;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class DeleteCustomerServlet extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        String id = req.getParameter("id");

        if (id == null || id.trim().isEmpty()) {
            res.sendRedirect("view-customers");
            return;
        }

        Customer customer = CustomerRepository.getCustomerById(id);
        if (customer == null) {
            req.setAttribute("error", "Customer not found.");
            req.getRequestDispatcher("/WEB-INF/error.jsp").forward(req, res);
            return;
        }

        req.setAttribute("customer", customer);
        req.getRequestDispatcher("/WEB-INF/confirm-delete.jsp").forward(req, res);
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        String id = req.getParameter("id");
        if (id == null || id.trim().isEmpty()) {
            req.setAttribute("error", "Customer ID is required for deletion.");
            req.getRequestDispatcher("/WEB-INF/error.jsp").forward(req, res);
            return;
        }

        boolean deleted = CustomerRepository.deleteCustomerById(id);
        if (deleted) {
            res.sendRedirect("view-customers");
        } else {
            req.setAttribute("error", "Failed to delete customer.");
            req.getRequestDispatcher("/WEB-INF/error.jsp").forward(req, res);
        }
    }
}
