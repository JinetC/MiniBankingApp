package com.example.bank;

import com.example.bank.database.CustomerRepository;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;
import com.example.bank.model.Customer;

public class CustomerViewServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        List<Customer> customers = CustomerRepository.getAllCustomers();
        req.setAttribute("customers", customers);
        RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/view-customers.jsp");
        dispatcher.forward(req, res);
    }
}
