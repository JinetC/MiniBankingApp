package com.example.bank.database;

import com.example.bank.model.Customer;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CustomerRepository {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/online_banking";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "1234";

    // Insert a new customer (ID assumed auto-generated)
    public static boolean insertCustomer(String fname, String lname, String address, String city,
                                         String branch, String zip, String dob, String nic,
                                         String phone, String email, String accountType, String regDate) {
        String sql = "INSERT INTO ACCOUNT (F_NAME, L_NAME, ADDRESS, CITY, BRANCH, ZIP, DOB, NIC, PHONE, EMAIL, ACCOUNT_TYPE, REG_DATE) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, fname);
            stmt.setString(2, lname);
            stmt.setString(3, address);
            stmt.setString(4, city);
            stmt.setString(5, branch);
            stmt.setString(6, zip);
            stmt.setString(7, dob);
            stmt.setString(8, nic);
            stmt.setString(9, phone);
            stmt.setString(10, email);
            stmt.setString(11, accountType);
            stmt.setString(12, regDate);

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Get all customers
    public static List<Customer> getAllCustomers() {
        List<Customer> list = new ArrayList<>();
        String sql = "SELECT * FROM ACCOUNT";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Customer c = mapResultSetToCustomer(rs);
                list.add(c);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    // Get savings accounts only
    public static List<Customer> getSavingsAccounts() {
        List<Customer> list = new ArrayList<>();
        String sql = "SELECT * FROM ACCOUNT WHERE ACCOUNT_TYPE = 'Savings'";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Customer c = mapResultSetToCustomer(rs);
                list.add(c);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    // Get customer by ID
    public static Customer getCustomerById(String id) {
        String sql = "SELECT * FROM ACCOUNT WHERE ID = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToCustomer(rs);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Update customer by ID
    public static boolean updateCustomerById(String id, Customer customer) {
        String sql = "UPDATE ACCOUNT SET F_NAME = ?, L_NAME = ?, ADDRESS = ?, CITY = ?, BRANCH = ?, ZIP = ?, DOB = ?, NIC = ?, PHONE = ?, EMAIL = ?, ACCOUNT_TYPE = ?, REG_DATE = ? WHERE ID = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, customer.getFname());
            stmt.setString(2, customer.getLname());
            stmt.setString(3, customer.getAddress());
            stmt.setString(4, customer.getCity());
            stmt.setString(5, customer.getBranch());
            stmt.setString(6, customer.getZip());
            stmt.setString(7, customer.getDob());
            stmt.setString(8, customer.getNic());
            stmt.setString(9, customer.getPhone());
            stmt.setString(10, customer.getEmail());
            stmt.setString(11, customer.getAccountType());
            stmt.setString(12, customer.getRegDate());
            stmt.setString(13, id);

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Delete customer by ID
    public static boolean deleteCustomerById(String id) {
        String sql = "DELETE FROM ACCOUNT WHERE ID = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, id);
            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Update balance and registration date
    public static boolean updateBalanceAndDate(String id, double balance, String regDate) {
        String sql = "UPDATE ACCOUNT SET BALANCE = ?, REG_DATE = ? WHERE ID = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setDouble(1, balance);
            stmt.setString(2, regDate);
            stmt.setString(3, id);

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean depositAmount(String id, double amount, String date) {
        // First get the current balance
        String selectSql = "SELECT BALANCE FROM ACCOUNT WHERE ID = ?";
        String updateSql = "UPDATE ACCOUNT SET BALANCE = ?, REG_DATE = ? WHERE ID = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement selectStmt = conn.prepareStatement(selectSql);
             PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {

            selectStmt.setString(1, id);
            ResultSet rs = selectStmt.executeQuery();

            if (rs.next()) {
                double currentBalance = rs.getDouble("BALANCE");
                double newBalance = currentBalance + amount;

                updateStmt.setDouble(1, newBalance);
                updateStmt.setString(2, date);
                updateStmt.setString(3, id);

                return updateStmt.executeUpdate() > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static boolean withdrawAmount(String id, double amount, String date) {
        String selectSql = "SELECT BALANCE FROM ACCOUNT WHERE ID = ?";
        String updateSql = "UPDATE ACCOUNT SET BALANCE = ?, REG_DATE = ? WHERE ID = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement selectStmt = conn.prepareStatement(selectSql);
             PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {

            selectStmt.setString(1, id);
            ResultSet rs = selectStmt.executeQuery();

            if (rs.next()) {
                double currentBalance = rs.getDouble("BALANCE");
                if (currentBalance < amount) {
                    // Not enough balance
                    return false;
                }
                double newBalance = currentBalance - amount;

                updateStmt.setDouble(1, newBalance);
                updateStmt.setString(2, date);
                updateStmt.setString(3, id);

                return updateStmt.executeUpdate() > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }



    // Utility: Map a ResultSet row to a Customer object
    private static Customer mapResultSetToCustomer(ResultSet rs) throws SQLException {
        Customer c = new Customer();
        c.setId(rs.getString("ID"));
        c.setFname(rs.getString("F_NAME"));
        c.setLname(rs.getString("L_NAME"));
        c.setAddress(rs.getString("ADDRESS"));
        c.setCity(rs.getString("CITY"));
        c.setBranch(rs.getString("BRANCH"));
        c.setZip(rs.getString("ZIP"));
        c.setDob(rs.getString("DOB"));
        c.setNic(rs.getString("NIC"));
        c.setPhone(rs.getString("PHONE"));
        c.setEmail(rs.getString("EMAIL"));
        c.setAccountType(rs.getString("ACCOUNT_TYPE"));
        c.setRegDate(rs.getString("REG_DATE"));
        c.setBalance(rs.getDouble("BALANCE"));
        return c;
    }
}
