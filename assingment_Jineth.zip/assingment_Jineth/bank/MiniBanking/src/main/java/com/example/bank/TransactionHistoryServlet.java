package com.example.bank;

import com.example.bank.database.TransactionRepository;
import com.example.bank.model.Transaction;

import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

public class TransactionHistoryServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        req.getRequestDispatcher("/WEB-INF/transaction-history.jsp").forward(req, res);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        String customerId = req.getParameter("customerId");
        String fromDate = req.getParameter("fromDate");
        String toDate = req.getParameter("toDate");

        List<Transaction> transactions = TransactionRepository.getTransactionsByCustomerIdAndDateRange(customerId, fromDate, toDate);
        req.setAttribute("transactions", transactions);
        req.setAttribute("customerId", customerId);
        req.setAttribute("fromDate", fromDate);
        req.setAttribute("toDate", toDate);

        req.getRequestDispatcher("/WEB-INF/transaction-history.jsp").forward(req, res);
    }
}
