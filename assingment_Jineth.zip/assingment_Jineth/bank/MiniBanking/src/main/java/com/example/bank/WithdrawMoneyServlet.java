package com.example.bank;

import com.example.bank.database.CustomerRepository;
import com.example.bank.model.Customer;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class WithdrawMoneyServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        req.setAttribute("customers", CustomerRepository.getAllCustomers());
        req.getRequestDispatcher("/WEB-INF/withdraw-money.jsp").forward(req, res);
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        String id = req.getParameter("id");
        double amount = Double.parseDouble(req.getParameter("amount"));
        String date = req.getParameter("date");

        Customer customer = CustomerRepository.getCustomerById(id);
        String message;
        if (customer == null) {
            message = "Customer not found.";
        } else if (customer.getBalance() < amount) {
            message = "Insufficient balance.";
        } else {
            boolean success = CustomerRepository.withdrawAmount(id, amount, date);
            message = success ? "Withdrawal successful." : "Withdrawal failed.";
        }
        req.setAttribute("message", message);
        doGet(req, res);
    }
}
