let name = "Jineth";

console.log(name);